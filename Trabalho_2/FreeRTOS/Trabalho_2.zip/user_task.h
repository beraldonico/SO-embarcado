#ifndef USER_TASK_H
#define	USER_TASK_H

void task_1();
void task_2();
void task_3();
void task_4();
void task_5();
void task_6();

#endif	/* USER_TASK_H */

